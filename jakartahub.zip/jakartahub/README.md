# Jakarta Hub (add-on CleanYourTV)

Kartu "Jakarta" di launcher CleanYourTV. Dibuka jadi layar penuh: cuaca Jakarta (Open-Meteo),
jadwal sholat (Aladhan, metode Kemenag), jadwal Persija (assets/persija.json).

Izin: INTERNET saja (untuk cuaca & jadwal sholat). Tanpa service background, tanpa telemetri.
