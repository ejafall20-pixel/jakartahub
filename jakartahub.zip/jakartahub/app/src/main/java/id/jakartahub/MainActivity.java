package id.jakartahub;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends Activity {

    // Opsional: isi dengan URL raw JSON (mis. raw.githubusercontent.com/...) supaya
    // jadwal Persija bisa diperbarui tanpa build ulang. Kosong = pakai assets/persija.json.
    private static final String PERSIJA_JSON_URL = "";

    private static final String WEATHER_URL =
            "https://api.open-meteo.com/v1/forecast?latitude=-6.2088&longitude=106.8456"
            + "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m"
            + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max"
            + "&timezone=Asia%2FJakarta&forecast_days=1";

    // method=20 = Kementerian Agama Republik Indonesia
    private static final String PRAYER_URL =
            "https://api.aladhan.com/v1/timingsByCity?city=Jakarta&country=Indonesia&method=20";

    private static final TimeZone WIB = TimeZone.getTimeZone("Asia/Jakarta");

    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView weatherTv, prayerTv, matchTv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(dp(56), dp(40), dp(56), dp(32));

        TextView title = new TextView(this);
        title.setText("Jakarta");
        title.setTextColor(Color.WHITE);
        title.setTextSize(34);
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        root.addView(title);

        TextView date = new TextView(this);
        SimpleDateFormat df = new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("id", "ID"));
        df.setTimeZone(WIB);
        date.setText(df.format(new Date()));
        date.setTextColor(0xFF9AA0A6);
        date.setTextSize(18);
        date.setPadding(0, 0, 0, dp(24));
        root.addView(date);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row, new LinearLayout.LayoutParams(-1, 0, 1f));

        weatherTv = addCard(row, "CUACA");
        prayerTv = addCard(row, "JADWAL SHOLAT (KEMENAG)");
        matchTv = addCard(row, "PERSIJA");

        TextView hint = new TextView(this);
        hint.setText("OK: muat ulang   ·   Kembali: keluar");
        hint.setTextColor(0xFF5F6368);
        hint.setTextSize(14);
        hint.setPadding(0, dp(16), 0, 0);
        root.addView(hint);

        setContentView(root);
        refresh();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            Toast.makeText(this, "Memuat ulang…", Toast.LENGTH_SHORT).show();
            refresh();
            return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    private TextView addCard(LinearLayout row, String heading) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(28), dp(24), dp(28), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF15181C);
        bg.setCornerRadius(dp(20));
        card.setBackground(bg);

        TextView h = new TextView(this);
        h.setText(heading);
        h.setTextColor(0xFFE8A33D);
        h.setTextSize(15);
        h.setLetterSpacing(0.1f);
        h.setPadding(0, 0, 0, dp(16));
        card.addView(h);

        TextView body = new TextView(this);
        body.setText("Memuat…");
        body.setTextColor(Color.WHITE);
        body.setTextSize(22);
        body.setLineSpacing(dp(6), 1f);
        card.addView(body);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
        lp.setMargins(dp(10), 0, dp(10), 0);
        row.addView(card, lp);
        return body;
    }

    private void refresh() {
        load(weatherTv, this::weatherText);
        load(prayerTv, this::prayerText);
        load(matchTv, this::matchText);
    }

    private interface Job { String run() throws Exception; }

    private void load(final TextView target, final Job job) {
        new Thread(() -> {
            String out;
            try {
                out = job.run();
            } catch (Exception ex) {
                out = "Gagal memuat.\nPeriksa koneksi internet TV.";
            }
            final String text = out;
            ui.post(() -> target.setText(text));
        }).start();
    }

    // ---------- Cuaca (Open-Meteo, tanpa API key) ----------
    private String weatherText() throws Exception {
        JSONObject j = new JSONObject(fetch(WEATHER_URL));
        JSONObject c = j.getJSONObject("current");
        JSONObject d = j.getJSONObject("daily");
        long temp = Math.round(c.getDouble("temperature_2m"));
        String cond = weatherLabel(c.getInt("weather_code"));
        long hum = Math.round(c.getDouble("relative_humidity_2m"));
        long wind = Math.round(c.getDouble("wind_speed_10m"));
        long min = Math.round(d.getJSONArray("temperature_2m_min").getDouble(0));
        long max = Math.round(d.getJSONArray("temperature_2m_max").getDouble(0));
        int rain = d.getJSONArray("precipitation_probability_max").optInt(0, 0);
        return temp + "°C\n" + cond
                + "\n\nLembap " + hum + "%"
                + "\nAngin " + wind + " km/j"
                + "\n\nHari ini " + min + "°–" + max + "°"
                + "\nPeluang hujan " + rain + "%";
    }

    private String weatherLabel(int code) {
        if (code == 0) return "Cerah";
        if (code <= 2) return "Cerah berawan";
        if (code == 3) return "Berawan";
        if (code == 45 || code == 48) return "Berkabut";
        if (code >= 51 && code <= 57) return "Gerimis";
        if (code >= 61 && code <= 67) return "Hujan";
        if (code >= 80 && code <= 82) return "Hujan lebat";
        if (code >= 95) return "Badai petir";
        return "Tidak diketahui";
    }

    // ---------- Jadwal sholat (Aladhan, metode Kemenag) ----------
    private String prayerText() throws Exception {
        JSONObject t = new JSONObject(fetch(PRAYER_URL)).getJSONObject("data").getJSONObject("timings");
        String[] keys = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};
        String[] names = {"Subuh", "Terbit", "Dzuhur", "Ashar", "Maghrib", "Isya"};

        SimpleDateFormat hm = new SimpleDateFormat("HH:mm", Locale.US);
        hm.setTimeZone(WIB);
        String now = hm.format(new Date());

        int next = -1;
        String[] times = new String[keys.length];
        for (int i = 0; i < keys.length; i++) {
            times[i] = t.getString(keys[i]).substring(0, 5);
            if (next < 0 && times[i].compareTo(now) > 0) next = i;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keys.length; i++) {
            sb.append(i == next ? "▶ " : "   ")
              .append(String.format(Locale.US, "%-9s", names[i]))
              .append(times[i]).append("\n");
        }
        return sb.toString().trim();
    }

    // ---------- Jadwal Persija (JSON statis) ----------
    private String matchText() throws Exception {
        String raw = null;
        if (PERSIJA_JSON_URL.length() > 0) {
            try { raw = fetch(PERSIJA_JSON_URL); } catch (Exception ignored) { }
        }
        if (raw == null) {
            try (InputStream in = getAssets().open("persija.json")) { raw = read(in); }
        }
        JSONArray arr = new JSONObject(raw).getJSONArray("matches");

        SimpleDateFormat parse = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        parse.setTimeZone(WIB);
        SimpleDateFormat show = new SimpleDateFormat("EEE, d MMM · HH:mm", new Locale("id", "ID"));
        show.setTimeZone(WIB);
        long nowMs = System.currentTimeMillis();

        List<String> lines = new ArrayList<>();
        for (int i = 0; i < arr.length() && lines.size() < 4; i++) {
            JSONObject m = arr.getJSONObject(i);
            Date d = parse.parse(m.getString("date") + " " + m.getString("time"));
            if (d == null || d.getTime() + 2 * 3600_000L < nowMs) continue;
            lines.add(show.format(d) + " WIB\n" + m.getString("home") + " vs " + m.getString("away"));
        }
        if (lines.isEmpty()) return "Belum ada jadwal.\nIsi assets/persija.json.";
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append("\n\n");
        return sb.toString().trim();
    }

    // ---------- util ----------
    private String fetch(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try (InputStream in = c.getInputStream()) { return read(in); }
        finally { c.disconnect(); }
    }

    private String read(InputStream in) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line).append('\n');
        return sb.toString();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
